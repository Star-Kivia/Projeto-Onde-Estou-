import React, { useEffect, useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  TouchableOpacity, 
  Modal,
  TextInput,
  ScrollView,
  Alert,
  StatusBar,
  ActivityIndicator
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@onde_estou_markers';

export default function App() {
  const [location, setLocation] = useState(null);
  const [markers, setMarkers] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [currentCoords, setCurrentCoords] = useState(null);
  const [markerName, setMarkerName] = useState('');
  const [markerDesc, setMarkerDesc] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedMarker, setSelectedMarker] = useState(null);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    await requestLocationPermission();
    await loadMarkers();
    setLoading(false);
  };

  const requestLocationPermission = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permissão Necessária',
          'Precisamos da sua localização para mostrar o mapa.',
          [{ text: 'OK' }]
        );
        return;
      }

      let loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      setLocation(loc.coords);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível obter a localização');
    }
  };

  const loadMarkers = async () => {
    try {
      const savedMarkers = await AsyncStorage.getItem(STORAGE_KEY);
      if (savedMarkers) {
        setMarkers(JSON.parse(savedMarkers));
      }
    } catch (error) {
      console.log('Erro ao carregar marcadores:', error);
    }
  };

  const saveMarkers = async (newMarkers) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newMarkers));
    } catch (error) {
      console.log('Erro ao salvar marcadores:', error);
    }
  };

  const handleMapPress = (e) => {
    setCurrentCoords(e.nativeEvent.coordinate);
    setMarkerName('');
    setMarkerDesc('');
    setSelectedMarker(null);
    setModalVisible(true);
  };

  const handleMarkerPress = (marker) => {
    setSelectedMarker(marker);
  };

  const addMarker = async () => {
    if (!markerName.trim()) {
      Alert.alert('Atenção', 'Digite um nome para o marcador');
      return;
    }

    const newMarker = {
      coordinate: currentCoords,
      name: markerName,
      description: markerDesc,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };

    const newMarkers = [...markers, newMarker];
    setMarkers(newMarkers);
    await saveMarkers(newMarkers);
    setModalVisible(false);
    setMarkerName('');
    setMarkerDesc('');
  };

  const updateMarker = async () => {
    if (!markerName.trim() || !selectedMarker) return;

    const updatedMarkers = markers.map(marker =>
      marker.id === selectedMarker.id
        ? {
            ...marker,
            name: markerName,
            description: markerDesc
          }
        : marker
    );

    setMarkers(updatedMarkers);
    await saveMarkers(updatedMarkers);
    setModalVisible(false);
    setSelectedMarker(null);
    setMarkerName('');
    setMarkerDesc('');
  };

  const removeMarker = async (id) => {
    Alert.alert(
      'Remover Marcador',
      'Tem certeza que deseja remover este marcador?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: async () => {
            const newMarkers = markers.filter(marker => marker.id !== id);
            setMarkers(newMarkers);
            await saveMarkers(newMarkers);
            if (selectedMarker?.id === id) {
              setSelectedMarker(null);
            }
          }
        }
      ]
    );
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    return distance.toFixed(2);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#9370DB" />
        <Text style={styles.loadingText}>Carregando...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#9370DB" barStyle="light-content" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Text style={styles.title}>🌍 Onde Estou?</Text>
          <Text style={styles.subtitle}>Seu app de localização</Text>
        </View>
        <TouchableOpacity 
          style={styles.refreshButton}
          onPress={requestLocationPermission}
        >
          <Ionicons name="navigate" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* Mapa */}
      <View style={styles.mapContainer}>
        {location ? (
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: location.latitude,
              longitude: location.longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
            onPress={handleMapPress}
            showsUserLocation
            showsMyLocationButton
            showsCompass
            showsScale
          >
            {markers.map((marker) => (
              <Marker
                key={marker.id}
                coordinate={marker.coordinate}
                title={marker.name}
                description={marker.description}
                pinColor="#9370DB"
                onPress={() => handleMarkerPress(marker)}
              />
            ))}
          </MapView>
        ) : (
          <View style={styles.mapPlaceholder}>
            <Ionicons name="location-outline" size={64} color="#9370DB" />
            <Text style={styles.mapPlaceholderText}>
              Aguardando localização...
            </Text>
          </View>
        )}
      </View>

      {/* Painel de Informações */}
      <View style={styles.infoPanel}>
        <View style={styles.panelHeader}>
          <Text style={styles.panelTitle}>
            {selectedMarker ? 'Marcador Selecionado' : 'Meus Marcadores'}
          </Text>
          <Text style={styles.markersCount}>
            {markers.length} marcador(es)
          </Text>
        </View>

        {selectedMarker ? (
          <View style={styles.selectedMarkerInfo}>
            <View style={styles.markerHeader}>
              <Text style={styles.selectedMarkerName}>
                {selectedMarker.name}
              </Text>
              <TouchableOpacity 
                onPress={() => setSelectedMarker(null)}
                style={styles.closeButton}
              >
                <Ionicons name="close" size={20} color="#666" />
              </TouchableOpacity>
            </View>
            <Text style={styles.selectedMarkerDesc}>
              {selectedMarker.description || 'Sem descrição'}
            </Text>
            {location && (
              <Text style={styles.distanceText}>
                📍 {calculateDistance(
                  location.latitude,
                  location.longitude,
                  selectedMarker.coordinate.latitude,
                  selectedMarker.coordinate.longitude
                )} km de distância
              </Text>
            )}
            <View style={styles.markerActions}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.editButton]}
                onPress={() => {
                  setMarkerName(selectedMarker.name);
                  setMarkerDesc(selectedMarker.description);
                  setCurrentCoords(selectedMarker.coordinate);
                  setModalVisible(true);
                }}
              >
                <Ionicons name="create-outline" size={16} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>Editar</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.actionButton, styles.deleteActionButton]}
                onPress={() => removeMarker(selectedMarker.id)}
              >
                <Ionicons name="trash-outline" size={16} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>Remover</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <ScrollView style={styles.markersScrollView}>
            {markers.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="pin-outline" size={48} color="#9370DB" />
                <Text style={styles.emptyStateText}>
                  Toque no mapa para adicionar seu primeiro marcador!
                </Text>
              </View>
            ) : (
              markers.map((marker) => (
                <TouchableOpacity
                  key={marker.id}
                  style={styles.markerItem}
                  onPress={() => handleMarkerPress(marker)}
                >
                  <View style={styles.markerColor} />
                  <View style={styles.markerInfo}>
                    <Text style={styles.markerName}>{marker.name}</Text>
                    <Text style={styles.markerDesc}>
                      {marker.description || 'Sem descrição'}
                    </Text>
                    {location && (
                      <Text style={styles.markerDistance}>
                        {calculateDistance(
                          location.latitude,
                          location.longitude,
                          marker.coordinate.latitude,
                          marker.coordinate.longitude
                        )} km
                      </Text>
                    )}
                  </View>
                  <TouchableOpacity 
                    onPress={() => removeMarker(marker.id)}
                    style={styles.deleteButton}
                  >
                    <Ionicons name="trash-outline" size={18} color="#FF6B6B" />
                  </TouchableOpacity>
                </TouchableOpacity>
              ))
            )}
          </ScrollView>
        )}
      </View>

      {/* Modal para adicionar/editar marcador */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {selectedMarker ? 'Editar Marcador' : 'Novo Marcador'}
            </Text>

            <Text style={styles.coordinatesText}>
              📍 Lat: {currentCoords?.latitude?.toFixed(6)}, Lng: {currentCoords?.longitude?.toFixed(6)}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Nome do local *"
              placeholderTextColor="#999"
              value={markerName}
              onChangeText={setMarkerName}
            />

            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Descrição (opcional)"
              placeholderTextColor="#999"
              value={markerDesc}
              onChangeText={setMarkerDesc}
              multiline
              numberOfLines={3}
              textAlignVertical="top"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setModalVisible(false);
                  setSelectedMarker(null);
                }}
              >
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmButton]}
                onPress={selectedMarker ? updateMarker : addMarker}
              >
                <Text style={styles.confirmButtonText}>
                  {selectedMarker ? 'Atualizar' : 'Adicionar'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F8FF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F8FF',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#9370DB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 15,
    backgroundColor: '#9370DB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  headerContent: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  subtitle: {
    fontSize: 14,
    color: '#E6E6FA',
    marginTop: 2,
  },
  refreshButton: {
    padding: 8,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
  },
  mapPlaceholderText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  infoPanel: {
    height: 250,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
    padding: 20,
  },
  panelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  panelTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  markersCount: {
    fontSize: 14,
    color: '#9370DB',
    fontWeight: '600',
  },
  selectedMarkerInfo: {
    flex: 1,
  },
  markerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  selectedMarkerName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 10,
  },
  closeButton: {
    padding: 4,
  },
  selectedMarkerDesc: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
    lineHeight: 20,
  },
  distanceText: {
    fontSize: 14,
    color: '#9370DB',
    fontWeight: '600',
    marginBottom: 15,
  },
  markerActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
  },
  editButton: {
    backgroundColor: '#9370DB',
  },
  deleteActionButton: {
    backgroundColor: '#FF6B6B',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  markersScrollView: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyStateText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 22,
  },
  markerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F8FF',
    padding: 12,
    marginVertical: 4,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#9370DB',
  },
  markerColor: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#9370DB',
    marginRight: 12,
  },
  markerInfo: {
    flex: 1,
  },
  markerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 2,
  },
  markerDesc: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  markerDistance: {
    fontSize: 11,
    color: '#9370DB',
    fontWeight: '500',
  },
  deleteButton: {
    padding: 8,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 8,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#9370DB',
    marginBottom: 16,
    textAlign: 'center',
  },
  coordinatesText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
    fontFamily: 'monospace',
    backgroundColor: '#F8F8FF',
    padding: 8,
    borderRadius: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E6E6FA',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    fontSize: 16,
    backgroundColor: '#F8F8FF',
    color: '#333',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: '#F8F8FF',
    borderWidth: 1,
    borderColor: '#E6E6FA',
  },
  confirmButton: {
    backgroundColor: '#9370DB',
  },
  cancelButtonText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '600',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});